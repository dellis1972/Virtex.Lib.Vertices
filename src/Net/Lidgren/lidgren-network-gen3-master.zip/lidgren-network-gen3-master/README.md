# lidgren-network-gen3 ![](https://travis-ci.org/lidgren/lidgren-network-gen3.svg)
Lidgren.Network is a networking library for .net framework which uses a single udp socket to deliver a simple API for connecting a client to a server, reading and sending messages.

